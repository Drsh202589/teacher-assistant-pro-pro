export interface PickPhoneContactResult { name: string; phone: string; }
export interface PhoneContactsPlugin { pickPhoneContact(): Promise<PickPhoneContactResult>; }
export declare const PhoneContacts: PhoneContactsPlugin;
